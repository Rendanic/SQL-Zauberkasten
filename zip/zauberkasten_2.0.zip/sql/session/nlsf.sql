--
-- Thorsten Bruhns (Thorsten.Bruhns@opitz-consulting.de)
-- $Id: nlsf.sql 233 2010-11-13 20:42:23Z tbr $
--
-- set nls_date_format in current session
--
alter session set nls_date_format='dd.mm.yy hh24:mi:ss';

