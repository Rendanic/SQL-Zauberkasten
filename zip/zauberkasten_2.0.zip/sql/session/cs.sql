--
-- Thorsten Bruhns (Thorsten.Bruhns@opitz-consulting.de)
-- $Id: cs.sql 233 2010-11-13 20:42:23Z tbr $
--
-- alter session set current_schema
--
-- Parameter 1. Username

alter session set current_schema=&1;

