--
-- Thorsten Bruhns (Thorsten.Bruhns@opitz-consulting.de)
--
-- Version: 1
-- Date   : 25.11.2013
--
-- set "_ORACLE_SCRIPT"=true in session
--
alter session set "_ORACLE_SCRIPT"=true;

