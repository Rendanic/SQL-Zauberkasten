--
-- Thorsten Bruhns (Thorsten.Bruhns@opitz-consulting.de)
-- $Id: cs.sql 244 2010-11-14 14:35:23Z tbr $
--
-- alter session set current_schema
--
-- Parameter 1. Username
--
alter session set current_schema=&1;

