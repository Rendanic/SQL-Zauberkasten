--
-- Thorsten Bruhns (Thorsten.Bruhns@opitz-consulting.de)
-- $Id: orad_tfn.sql 253 2010-11-23 21:34:55Z tbr $
--
-- Display tracefile-name for session in oradebug
--
oradebug tracefile_name

